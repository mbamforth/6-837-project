README - Assignment #2
Miren Bamforth

1) You compile the code by typing make while in the correct directory. You run it with debug/a2 data/ModelName.

2) I did not collaborate with anyone. I discussed some things with Raluca Ifrim when she was stuck.

3) I looked at wikipedia, C++ documentation, and a bunch of things that were linked to from the piazza site.

4) There is an error with the euler rotations. The joints move incorrectly. The mesh follows the joints, so the issue is likely in setJointTransform although I have not been able to fix it so far. Additionally, some of the faces are redrawn incorrectly (but initially drawn correctly) for some of the models. It is very few faces per model so I am having difficultly isolating the issue.

5) I didn't do any extra credit.

6) This was good! I liked how it guided me enough so that I knew what was expected but still left a lot of room for me to learn and figure things out on my own.
